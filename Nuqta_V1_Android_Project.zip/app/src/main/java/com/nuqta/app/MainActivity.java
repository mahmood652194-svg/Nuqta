package com.nuqta.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout root;
    TextView balance;

    TextView tv(String s, int size) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.DKGRAY);
        t.setPadding(24,18,24,18); return t;
    }
    Button btn(String s) { Button b=new Button(this); b.setText(s); return b; }

    public void onCreate(Bundle b) {
        super.onCreate(b); showLogin();
    }

    void showLogin() {
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(35,50,35,30);
        root.addView(tv("نقطة",34)); root.addView(tv("حسابك المالي في مكان واحد",20));
        EditText user=new EditText(this); user.setHint("اسم المستخدم"); root.addView(user);
        EditText pass=new EditText(this); pass.setHint("كلمة المرور"); pass.setInputType(129); root.addView(pass);
        Button login=btn("تسجيل الدخول / إنشاء حساب"); root.addView(login);
        login.setOnClickListener(v -> showHome(user.getText().toString()));
        setContentView(root);
    }

    void showHome(String name) {
        root.removeAllViews();
        root.addView(tv("مرحباً "+(name.length()>0?name:"بك")+" 👋",25));
        root.addView(tv("نقطة — نسخة تجريبية قابلة للتوسعة",16));
        balance=tv("الرصيد التجريبي\n\nUSD: $40,000,000\nSYP: 2,000,000,000",24);
        root.addView(balance);
        Button history=btn("📋 سجل الحركات"); root.addView(history);
        Button qr=btn("▣ QR / باركود"); root.addView(qr);
        Button logout=btn("تسجيل الخروج"); root.addView(logout);
        history.setOnClickListener(v -> {
            new AlertDialog.Builder(this).setTitle("سجل الحركات")
            .setMessage("لا توجد حركات حقيقية.\nهذه الأرصدة والبيانات تجريبية فقط.")
            .setPositiveButton("حسناً",null).show();
        });
        qr.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("QR / باركود")
            .setMessage("واجهة الكاميرا جاهزة للإضافة في المرحلة التالية.")
            .setPositiveButton("حسناً",null).show());
        logout.setOnClickListener(v -> showLogin());
    }
}
